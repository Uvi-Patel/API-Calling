//
//  ViewController.swift
//  API Calling
//
//  Created by MAC on 15/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireImage
class ViewController: UIViewController {
    
//    @IBOutlet weak var tblView: UITableView!
//    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var imagView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        /*   Alamofire.request("https://jsonplaceholder.typicode.com/posts/1").responseJSON { (response) -> Void in
            if let JSON = response.result.value{
                print(JSON)
            }*/
//        get()
        post()
//        postImage()
        }
    
    func post(){
            var urlRequest = URLRequest(url: URL(string: "https://jsonplaceholder.typicode.com/albums")!)
            urlRequest.httpMethod = "POST"
            let dataDictionary = ["userId": "11",
                                  "title": "welcome"]
    /*    Alamofire.request("https://jsonplaceholder.typicode.com/albums", method: .post, parameters: dataDictionary, encoding: URLEncoding.httpBody)
        .responseJSON { response in
            print(response)
        }*/
            do {
                let requestBody = try JSONSerialization.data(withJSONObject: dataDictionary, options: .prettyPrinted)

                urlRequest.httpBody = requestBody
                urlRequest.addValue("application/json", forHTTPHeaderField: "content-type") // this line is very important as explained in the video
            } catch let error {
                print(error.localizedDescription)
            }

            URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in

                if(data != nil && data?.count != 0)
                {
                    let response = String(data: data!, encoding: .utf8)
                    print(response!)
                }
            }.resume()
        }
    
    func get()
    {
        var urlRequest = URLRequest(url: URL(string: "https://jsonplaceholder.typicode.com/photos")!)

        urlRequest.httpMethod = "get"

        URLSession.shared.dataTask(with: urlRequest) { (data, httpUrlResponse, error) in
            if(data != nil && data?.count != 0)
            {
                let response = String(data: data!, encoding: .utf8)
                print(response!)
            }
        }.resume()
    }
    
    func postImage(){
         let image = UIImage.init(named: "whatsapp")
//        imagView.image = image
        let imgData = image!.jpegData(compressionQuality: 0.2)!
//        imagView
//        print(image)

        let parameters = ["title": "whatsapp","url": "whatsapp"] //Optional for extra parameter

        Alamofire.upload(multipartFormData: { multipartFormData in
                multipartFormData.append(imgData, withName: "fileset",fileName: "file.jpg", mimeType: "image/jpg")
                for (key, value) in parameters {
                        multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
                    } //Optional for extra parameters
            },
        to:"https://jsonplaceholder.typicode.com/photos")
        { (result) in
            switch result {
            case .success(let upload, _, _):

                upload.uploadProgress(closure: { (progress) in
                    print("Upload Progress: \(progress.fractionCompleted)")
                })

                upload.responseJSON { response in
                     print(response.result.value)
                }

            case .failure(let encodingError):
                print(encodingError)
            }
        }
    }
}
